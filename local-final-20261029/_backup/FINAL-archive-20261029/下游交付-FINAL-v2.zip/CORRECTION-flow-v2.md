# 更正说明 · FINAL 交付包 v2（flow.js 修复，2026-10-29）

本包（下游交付-FINAL-v2.zip）是 2026-10-28 的 下游交付-FINAL.zip（v1，SHA256 e649637d…）的更正版，只改一件事：

- v1 的 `products/flow.js` 是错版（2747B，LangMgr 文案数据，无 onTick），冷启动会报“flow 契约不符”停在选服界面。该缺陷由下游 Agent 实机测试发现，Muse 已在树内复核并裁定（见 v1 包外复核文件 REAL-MACHINE-TEST-REVIEW-20261029.md）。
- v2 的 `products/flow.js` 为本机真 flow：17862B，SHA256 `bc8b98be0653656cca897f26468a7feff1b66b6165ec1681924065e33fe02039`，含 onTick 契约，由下游 Agent 从实机回传，Muse 按哈希与契约逐项验过后修复了源头文件 `hotfix-patch/live/flow.js` 并重新 build 产出（build 日志 FLOW OK bytes=17862）。
- `products/handlers.js` 与 v1 逐字节一致（1814791B，SHA256 `40d2ca24…`），版本号仍为 hf5d89bf7，selfCheck 1514。修复后六门已全套重跑全绿（gen 382/1130、build hf5d89bf7、freeze diff 0、reject 268/285/391、acceptance 57/57 已知红 0、lint 44/42/0 白名单 2），日志在 Muse 工作区 final/flow-repair/gates/。
- 包内 FINAL-RECEIPT.md 为 v1 原件，其中涉及 flow 的旧记载（2747B / b7cd1c13…）以本更正说明为准，其余内容不变。
- 实机现状（下游第二轮复测回报，2026-10-29）：实机已装 v1 的 handlers.js + 本机真 flow，冷启动自动进 gamescene，ver 为 impl=hf5d89bf7、flow=ffaec47c3，第 8 项复测通过，第 1–7 项维持“UI 不可达（未执行）”定案。与 v2 包状态哈希一致，实机无需重装。本包仅作存档定版。
