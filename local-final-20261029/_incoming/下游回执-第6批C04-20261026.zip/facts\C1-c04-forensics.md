# C1 · 第 6 批 C04〔婚姻子女〕取证与策略（2026-10-26）

> 侦察：scoutA-reqkeys.md（21 动作逐字段，工人A）+ scoutB-tables.md（dump 表全清，工人B）；主审抽样复核（propose/make/bridalline 三表数字、21 个 HttpConst 行号）逐项一致。

## 一、成员与线上名（HttpConst 全在 index.js:59613-60566）

16 主动作 + 5 面板配套，KEY→线上名见 scoutA；注意 USE_WIFE_PROP → `User.UserWifeProp`（双写，H 键 = UserWifeProp）。

## 二、表

| 表 | 行数 | 内容 | 奖励列 |
|---|---|---|---|
| propose.json | 36 | 键=Npcid（提亲/结婚 NPC 白名单），含 Pre_Taskid/Require 等 | **无** |
| make.json | 5 | 键=id 1..5（同床档位动画/文案/数值效果） | **无** |
| bridalline.json | 9 | 婚礼巡游路线（Menpai 1..9） | **无** |

**三表均无 award/reward/price 类列**（scoutB 逐列核对）→ 本批没有发钱口。
其余 15 个关键词 0 命中 → 子女/妻子子系统无配置表，状态全在 marryObj（TPL 抓包快照 24 键）。

## 三、策略判定（三分）

1. **状态机·实现**（写 s.marryObj，LoadGame 回放）：
   - proposeNpc：合法 NPC（BZ_PROPOSE）→ 入册（幂等）；已婚 → 11；不在表 → 12。
   - marryNpc：未提亲 → 4；已婚 → 3；成功写 marryNpc/marryTime。
   - divorceNpc：未婚 → 2；已婚清婚姻字段回模板初值（childObj 保留），回旧配偶 id。
   - beginWedding：未婚 → 2；已婚 → 1。
   - makeLove：未婚/choose 不在 BZ_MAKE → 2；成功 eRet 1 + makeID（显示型，77308 hasOwnProperty）；妊娠分支（eRet 5 + fetationTime）不建模。
2. **面板·实现**：GetWhoreData → `{eRet:1, girlData:{}}`（同面板必做，面板能开零数据）；getLikeEvent → eRet 4（客户端自有"无事件"流 dialog 1810121，不伪造 like_event）。
3. **子系统未建模·锁死**（13 个）：birthChild 2 / chooseSex 3 / adoptChild 2（原版付费，else 即 openChargeList）/ giveChildName 2 / childWashProperty 2 / resetChildFoster 4（有专属文案）/ addChildFoster 2（静默）/ upgradeWifeLevel 2 / UserWifeProp 2（不扣道具）/ ChooseGirl 2 / Whoring 2 / optionLikeEvent 2。
   锁死依据：childObj / wifeUpdateData / 属性模型形状无证据（造形状=假数据=子 UI 崩点）；领养/洗练/青楼原版是消耗/付费功能，价格无源；全部取各回调的"条件不满足"或静默分支（少发方向）。

## 四、关键证据（index.js）

- 提亲/结婚/离婚消费：77123-77127 / 77236-77254 / 77257-77264
- 婚礼/同床/礼金：77272-77273 / 77278-77337 / 77266-77270
- 儿童族：24613-24800（setChildName/childWash/resetFoster/adoptChild/chooseSex 的注册与消费）
- 妻子族：145326-145394（upgradeWifeLevel/UserWifeProp，sendReqWithMask {lv,exp,pot}/{propnum}）
- 青楼族：51112-51376（GetWhoreData/ChooseGirl/Whoring/getLikeEvent/optionLikeEvent）
- makeID 显示链：77308 `e.hasOwnProperty("makeID")`；51147（Whoring 处）同源

## 五、形状审批

C04 全部 21 动作**在 337 形状基线里**（原服有实现）→ 39 项差异走审批三件套：
- planned-changes.json：7 条规则精确覆盖 39 项（eRet×17 / npcID×4 / npcId×1 / exp+lv×4 / childObj×2 / 杂项×10 / equipObj add×1），sigma 变化全部逐项 allowSigma + index.js 行号证据。
- approved-narrowing.json：+21 条（escape:"closed"，逐条逃逸结论——拒绝分支不读被收窄字段）。
- approved-widening.json：+1 条（marryAward|equipObj 空对象）。
- evidence-sha1.json：+attrList 证据点（index.js:24634）。
