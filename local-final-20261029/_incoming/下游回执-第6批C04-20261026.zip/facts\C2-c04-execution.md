# C2 · 第 6 批 C04 执行记录（2026-10-26）

## 改动清单

| 文件 | 改动 |
|---|---|
| tools\gen_shop_tables.js | +BZ_PROPOSE（36 NPC 存在表）+BZ_MAKE（5 档） |
| tools\facts\reject-codes.json | +18 动作（proposeNpc/marryNpc/divorceNpc/beginWedding/makeLove/birthChild/chooseSex/adoptChild/giveChildName/childWashProperty/resetChildFoster/addChildFoster/upgradeWifeLevel/UserWifeProp/ChooseGirl/Whoring/getLikeEvent/optionLikeEvent），ev 全部 index.js 行号+sha8 |
| hotfix-patch\core\bz-rpc-server.js | +marryState() 槽（TPL 快照补齐）；LoadGame +marryObj 回放；H +20 个 handler（状态机 5 + 面板 2 + 锁死 13）；REJECT_CODES +18 |
| tools\golden\{planned-changes,approved-narrowing,approved-widening}.json | 形状审批三件套（39 项差异，见 C1 §五） |
| tools\golden\evidence-sha1.json | +attrList（index.js:24634） |
| hotfix-patch\test\c04-smoke.js | 新增 9 条 |
| hotfix-patch\probe\c04-verify-probe.js | 真机验证探针 |
| tools\tmp_c04_wires.js / tmp_c04_rejects.js / tmp_c04_shape_approvals.js | 一次性取证/登记脚本（留档） |

## v2.7.1-accept 小改结论（写回执用的一句）

a 不会：单次冒险客户端只发一个分支（五条流各自一次 reqAdvReward 收尾，应答到达即 end() 清 advCurId；分支 3 走镖牌结束流 29269，与战斗流互斥）——仍按指示做了胜负组 {1,2,4} / 领取组 {3,5} 两组记账防御隔离；b 会：gsp_event 109 行固定表随机触发，s.advDone 已改 {d:todayKey,w,c} 按天清空。**另揪出真 bug：客户端 adventureID 恒为 0（advCurId 从不赋真值），真正键是 eventID=gsp_event 行 id——已按 eventID 反查实现，否则功能永远匹配不到行。**真机验证见下。

## 门禁

| 项 | 结果 |
|---|---|
| build-handlers | OK ver=hb6cbc053，selfCheck **1284** 全过（+20 条新 handler 检查） |
| check_shape_freeze | C1-C13 全过（39 项差异经审批三件套 --freeze 入基线，动作 337） |
| acceptance | **45/45 绿**（+c04-smoke），known-red 0，cap 0 |
| check_reject_codes | OK 动作 **65** / 条目 **73** / 拒绝点 **98** |
| c04-smoke | 9/9 |
| 热重载 | pid 不变、impl=hb6cbc053、implErr=null |
| 独立验收 | 工人 13 条全量复跑（acceptance-worker-report.md） |

## 真机验证（probe\c04-verify-probe.js，全链）

- propose(1007)→1；marry(1007)→1；重复结婚→3；LoadGame 回放 marryNpc=1007
- makeLove(choose=2)→1 + makeID=2（显示型）
- marryAward → 1 + 空 rewardArray，coins 零增量（白拿闸实证）
- 锁死抽样：birthChild 2 / adoptChild 2 / Whoring 2；GetWhoreData → girlData{}；getLikeEvent → 4
- propose(9999) → 11（当时已婚——已婚判定先于表校验，顺序正确）
- divorce → 1 + 旧配偶 id，marryNpc=0 / proposeNpc 清空 / coins 不变（真档已还原未婚态）

## 回滚

| 对象 | 位置 |
|---|---|
| 本轮源文件改前原件 | `_backup\20261026-172536-pre-v271\`（core/patch-live/tools/test 全量） |
| 形状基线 | `--freeze` 前基线在 git 无、tools\golden\emission.json 由冻结器自动归档？——否：冻结器覆盖写；回滚 = 用备份 tools\golden 重跑 gen_shapes+build |
| 存档 | 真档本轮动过 marryObj（已由离婚清场还原未婚态）+ advDone |
