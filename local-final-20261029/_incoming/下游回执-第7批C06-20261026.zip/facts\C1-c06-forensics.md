# C1 · 第 7 批 C06〔打坐练功〕取证与策略（2026-10-26）

> 侦察：scoutD-c06-reqkeys.md（15 动作逐字段，工人）。主审抽样：HttpConst 15 行号、四模块别名、关键消费行一致。

## 一、成员与现状

15 动作（relations.md:53-56）中 **4 个前批已实现**（BeginTraining/BeginMeditation/BeginPlayWooks/EndPlayWooks，R13/挂机批），本批补 **11 个**。
使用点全部只在 index.js（scripts2/3 双方式 grep 零命中），分属 HangUpModel(56187)/MuzhuangModel(86141)/SkillUpgradeModel(120469)/TrainingMpModel(138860) 四模块。

## 二、消费端关键事实（决定应答形状）

1. **三个 END_* 回调没有 eRet 判断**（120574 / 138888 / 138903 直接读字段）→ 字段必须给齐：
   genguTime/hanyusuiTime（buff 秒数）给 0；**EndMeditation 的 138892 `o.note.hasOwnProperty("attrch")` 无守护 → note 必须存在**（缺了 TypeError），note 四本空账本一并给（贴基线形状，省 4 条 narrowing）。
2. vigor（体力）无存档槽 → getVigor/useVigorMeditation/useVigorUpGradeSkill 恒 vigor 0（诚实空态）。
3. useVigorUpGradeSkill 的 120604 `getSkillLevel(e.skillID)` 拼文案 → skillID 必须回声（客户端本地表查它自己报的 id，无奖励面）。
4. BEGIN_RECOVER_MP：serverTime 写 recoverStartTS（回蓝计时基座）→ 回 env.now()。
5. relations.md 预警采纳：END_LIANGONG/END_DAZUO「请求不带时长，只回成功不结算」——练功收益/内功修为/体力消耗全部不建模。
6. Implantation/removeMartial 的 skillQueue 是客户端本地模型 → ack。

## 三、形状审批

4 项差异：BeginRecoverMP|serverTime（num0→num+，planned 1 条 + allowSigma + ev index.js:138898）+
hanyusuiTime 新发 ×3（approved-widening 3 条，ev index.js:138891）。--freeze 入基线后 C1-C13 全过。
