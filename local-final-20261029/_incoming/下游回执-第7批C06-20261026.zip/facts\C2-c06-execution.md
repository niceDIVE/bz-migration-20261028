# C2 · 第 7 批 C06 执行记录（2026-10-26）

## 改动清单

| 文件 | 改动 |
|---|---|
| hotfix-patch\core\bz-rpc-server.js | +11 个 handler（EndTraining/EndMeditation/EndRecoverMP/getVigor/useVigorMeditation/useVigorUpGradeSkill/BeginRecoverMP/changePlayWooksState/setOnHookWookState/Implantation/removeMartial）；全部 eRet 1、无发钱口、无 REJECT_CODES 新增 |
| tools\golden\approved-widening.json | +3（hanyusuiTime 新发 ×3） |
| tools\golden\planned-changes.json | +1（c06-servertime） |
| hotfix-patch\test\c06-smoke.js | 新增 6 条（含"11 动作跑完存档逐字节不动"） |
| hotfix-patch\probe\c06-verify-probe.js | 真机验证探针 |

## v2.7.1-accept2 拍板落地（同轮）

| 拍板 | 落地 |
|---|---|
| 领养：深挖 childData，推出形状→500 元宝解锁 | **推出成功**（scoutC 52 行读点 + 主审亲验 9 处危险读点；childObj 9 键全有出处）→ adoptChild 解锁（500 元宝先扣、未婚/已有孩子/不足回 2）、birthChild 接线（闸=fetationTime>0，实际自然锁死）、giveChildName 接线（空名→99 走 getText(480)） |
| makeLove：经验进 s.exp、每日 5 次 | 50/次（**make.json experience 列实测是风味文案 id 1410006-1410010，全表无数值源**——make-text-probe 实取，回执申报）+ s.makeLoveDay/todayKey 限 5 次，超限 eRet 2；happiness 只显示；hunger/full 不接（客户端不读） |

## 门禁

| 项 | 结果 |
|---|---|
| build-handlers | OK ver=h9de8c1d7，selfCheck **1285** 全过 |
| check_shape_freeze | 4 项差异（serverTime 1 + hanyusuiTime 3）审批后 --freeze，C1-C13 全过（动作 337） |
| acceptance | **46/46 绿**（+c06-smoke 6 条） |
| check_reject_codes | OK 动作 65 / 条目 79 / 拒绝点 102 |
| c04-smoke / v271 / c16 / circle / c03 / c02 / c05 | 12/12、15/15、6/6、10/10、15/15、11/11、19/19、16/16 |
| 热重载 | pid 不变、impl=h9de8c1d7、implErr=null |
| 独立验收 | 本批未派（薄 ack 批，11 个动作全 eRet 1 无业务分支；主审全量自跑 + 真机全链）——**回执注明** |

## 真机验证（probe\c06-verify-probe.js）

11 动作全 eRet 1；EndMeditation note.attrch 链路通（无 TypeError）；vigor 0；useVigorUpGradeSkill 回声 skillID=7；
BeginRecoverMP serverTime 有值；**before/after 数值完全一致**（coins 20832359 / exp 450 / potential 102799 —— 不结算批实证，零白拿面）。
makeLove 链真机：5 次 exp 200→450（+250 封顶）、第 6 次 eRet 2、离婚清场 exp 保留。
