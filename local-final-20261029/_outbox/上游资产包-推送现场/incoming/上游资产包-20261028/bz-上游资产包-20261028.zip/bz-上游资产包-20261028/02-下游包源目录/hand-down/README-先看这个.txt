本包按顺序做：
00-指令-第1批收尾.txt   拍板事项、三条尾巴、面板维度（extract_panel）
01-指令-第2批-道具使用.txt
bz-oracle/forge/analysis/   改进后的算法（relate v2.2 + 新增 extract_panel.py），合并进 v2.3 目录，覆盖同名文件
