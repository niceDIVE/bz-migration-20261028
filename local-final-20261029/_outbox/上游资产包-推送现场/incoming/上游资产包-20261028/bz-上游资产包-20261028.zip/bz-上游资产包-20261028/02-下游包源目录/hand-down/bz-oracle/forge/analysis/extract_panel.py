#!/usr/bin/env python3
"""extract_panel.py：给每个客户端回调点标上它所在的脚本（≈ UI 面板）。

用法：python forge/analysis/extract_panel.py <客户端 js 文件...>  > panel.json
     再跑 relate.py --panel panel.json

做法：Cocos Creator 2.x 的打包产物里，每个脚本开头都有 cc._RF.push(module, "uuid", "脚本名")，
结尾是 cc._RF.pop()。按这两个标记切出「行号区间 → 脚本名」，再把 out/contracts.json 里每个动作的
sites（file:line）落到区间里。没有 _RF 标记时，退一步认 `cc.Class({ name: "X"` 和 `cc._RF.push` 之外的
`window.X = cc.Class(` 写法；一个都找不到就在 stderr 说明，输出为空（relate 会照常跑，只是不挂面板）。

输出：{"User.GetMarketList": ["StoreView"], ...}；stderr 打印脚本区间数和落点率。
"""
import io, json, os, re, sys, bisect

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
RF = re.compile(r'cc\._RF\.push\(\s*\w+\s*,\s*["\'][^"\']*["\']\s*,\s*["\']([^"\']+)["\']')
CLS = re.compile(r'(?:window\.(\w+)\s*=\s*cc\.Class\(|cc\.Class\(\{\s*name\s*:\s*["\'](\w+)["\'])')


def spans(path):
    starts = []
    with io.open(path, encoding="utf-8", errors="replace") as f:
        for i, line in enumerate(f, 1):
            for m in RF.finditer(line): starts.append((i, m.group(1)))
            if not starts or starts[-1][0] != i:
                m = CLS.search(line)
                if m and not RF.search(line): starts.append((i, m.group(1) or m.group(2)))
    starts.sort()
    return starts


def main():
    sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8")
    files = sys.argv[1:]
    if not files: sys.exit(__doc__)
    con = json.load(io.open(os.path.join(ROOT, "out", "contracts.json"), encoding="utf-8"))["contracts"]
    by_base = {}
    for p in files:
        sp = spans(p); by_base[os.path.basename(p)] = sp
        print(f"# {os.path.basename(p)}：{len(sp)} 个脚本区间", file=sys.stderr)
    out, hit, tot = {}, 0, 0
    for c in sorted((c for c in con.values() if c.get("action")), key=lambda x: x["action"]):
        for st in c.get("sites", []):
            sp = by_base.get(os.path.basename(st["file"]))
            if sp is None: continue
            tot += 1
            i = bisect.bisect_right([s[0] for s in sp], st["line"]) - 1
            if i < 0: continue
            hit += 1
            out.setdefault(c["action"], [])
            if sp[i][1] not in out[c["action"]]: out[c["action"]].append(sp[i][1])
    print(f"# 回调点 {tot} 个，落进脚本区间 {hit} 个；{len(out)} 个动作拿到了面板名", file=sys.stderr)
    print(json.dumps({k: sorted(v) for k, v in sorted(out.items())}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
