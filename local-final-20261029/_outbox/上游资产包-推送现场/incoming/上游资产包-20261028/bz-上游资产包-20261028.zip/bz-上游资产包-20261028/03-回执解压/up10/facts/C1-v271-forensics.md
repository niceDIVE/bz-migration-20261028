# C1 · v2.7.1 三件拍板取证（2026-10-26）

> 全部结论有 `文件:行号` 锚点；行号均出自 `tools\index.js` / `tools\scripts2.js` / `tools\scripts3.js`（客户端三包）与本工程 core。

## 一、拍板 1：经验 4002 的客户端落点（走「找到了」分支）

- LoadGame 应答消费块：`index.js:111756-111801` 逐槽把 `baseValueAy[N]` 投进 `RoleBaseInfo`；
  **经验 = [18]**：`111775 v.RoleBaseInfo.exp = t.baseValueAy[18]`（旁证 `74939 t.exp = e.baseValueAy[18]`，parsePlayerData）。
- 服务端 eco 监听口径（core 注释 925，源自 `tools/index.js:64698-64725 ECONOMY_CHNG`）本来就认 `exp` 键 → `note.eco.exp` 客户端直接吃。
- 结论：存档新增 `s.exp`（缺省 0），领奖经 `CURRENCY_SLOTS[4002] = {f:'exp', k:'exp'}` 入账，LoadGame 按 `[18]` 投射。

## 二、拍板 2：adventure 奖励与分支码

### 2.1 item id 1..5 的身份（活体探针，LangMgr.getText，游戏进程内实取）

| item id | item.json Type | Name 文本id | 显示名 | 钱包落点 |
|---|---|---|---|---|
| 1 | 6 | 506 | **金条** | `s.gold`（CURRENCY_SLOTS 既有）|
| 2 | 7 | 676 | **善恶** | 无 |
| 3 | 8 | 816 | **筹码** | 无 |
| 4 | 9 | 1239 | **幸福度** | 无 |
| 5 | 12 | 3051 | **幻境之尘** | 无 |

对照组：33001/33002/33003 = 银两/江湖经验/潜能（与既有口径一致）。探针产物 `probe\lang-v271-probe.js`。
adventure.json 四列（awardwin/awardfalse/award/award2，109 行）**只出现 id 2/3/4**（脚本统计），即本轮接线后全部是"只显示"型。

### 2.2 列编码是单个扁平对

全表非空列长度恒为 2（awardwin:2×45、award:2×63、award2:2×36、awardfalse:2×29），**没有多对连写**。
负数量 = 惩罚条目（`award=[4,-2]`、`award2=[4,-1]`）。生成器 `flatPair()` 归一化为 `[[id,数]]`。

### 2.3 分支码（award 形参）全景——客户端共 5 档，不止上游说的 4 档

| 分支 | 发起点 | 语义 | 本工程选列 |
|---|---|---|---|
| 1 | `index.js:88678` successFuncCallBack | 战斗胜利结算 | awardwin |
| 2 | `index.js:88703` failFuncCallBack | 战斗失败结算 | awardfalse |
| 3 | `index.js:88635` reqAwards | 领取 | award |
| 4 | `index.js:88577` quickVitorFinish→getRewardData(4) | **快胜结算（上游未列，客户端实证存在）** | awardwin |
| 5 | `index.js:88593` quickFailFinish→getRewardData(5) | 快败结算 | award2 |

请求形状：`{adventureID, award, eventID}`（`index.js:143865-143869`）。
应答消费：`index.js:143814-143840` **只读 rewardArray/npcArr/liveness，不判 eRet**；
显示直接 `a.getItem(l,"item")` + `getText(d.Name)`（143826-143827）→ 与 2.1 的显示链一致。

## 三、拍板 3：成就进度模型

### 3.1 进度与达成的归属

- 应答消费 `scripts3.js:2899-2918`：`2905 t.tObj = o.taskData` —— 进度对象**本来就来自服务端应答**。
- 达成判定 `scripts3.js:3305 checkAchieved = awardIds.includes || receivedIds.includes` —— 也在服务端（awardIds = 我方 `achieveIdArr`）。
- 进度键约定 `scripts3.js:3055`：`type_type1`（c 键）与 `type_type1_require`（p 键）。
- 目标值口径 `scripts3.js:3220-3266`（getPrg）：`"0"|... → 列表长`、`n<=0 → times`、1/5 特例等。

### 3.2 57 种 type/type1 的语义（des 文本活体探针逐类定案）

可判四类（≈1545/2113 行）：
1. **收集/持有**：type 3 全部 + type 2/3（全家福）——require `"0|id,..."` 全持有 / `"1|..."` 至少 1 个；持有 = bag ∪ skills ∪ knackBag（3/11=skill_Trick 口诀，`index.js:70503` skillGrasp 消费）。
2. **任务数**：6/1,0（告示牌，des 逐条确认）= `s.taskDoneCount`；6/2,0（环任务）= `s.circleTotal`；目标 = times。
3. **经验**：1/3（des "江湖经验达到5000"）= `s.exp`（"记录最高"用当前值做下界，只紧不松）。
4. **技能等级**：1/5（des "读书识字达到10级"）= `s.skills` 等级，分支逻辑逐句照抄 `scripts3.js:3093-3105`。

锁死类（不做，不问口径）：1/1、1/2（有效/综合等级——等级未落地）、2/2、2/8（无量天机积分/拾取）、2/5（登录天数）、2/6（建号天数）、2/7_x（妙手空空）、5/x（无量天机各族）、7/x（排行榜）、3/2 中时装（fashion 不在存档）、1/4、1/7、1/8、1/10、1/12、1/13、1/14、1/15、1/17、1/18、1/19、1/20（房产/转生/师门/称号/琅嬛/天机段位/根骨丹/身材等，条件不在存档）。

### 3.3 真实存档 pending 复核（防虚报抽检）

部署后真档 `getAchieveData`：pending **26** 条。本地用同一存档复跑逐条核对：
- 带实物奖励的 14 条全部真达成：419-450（1/5 读书识字 skill 9/7/8 等级 10..40，`s.skills` 直查）+ 472（6/2,0 完成 1 次环任务，reward 4002×1000，circleTotal=4）。
- 其余 12 条（3/1×3、3/3×1、3/4×3、3/5×4、3/11 未进）**rw 全部 = "0"**——零奖励面，即使 3/4/3/5 id 空间未证实（见 OPEN-ISSUES ISSUE-7）也无欺诈路径。
