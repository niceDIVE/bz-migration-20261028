# C2 · v2.7.1 执行记录（2026-10-26）

> 前置：交接 `HANDOVER-SESSION-2026-10-26.md`；备份 `_backup\20261026-172536-pre-v271\`（core + patch\live\handlers.js + tools + test，开工前全量）。
> 上游包：`_incoming\v2.7.1-20261026\`（00 说明 + README.md + extract_shape.py，sha256 10b2b817…）。

## 一、改动清单

| 文件 | 改动 |
|---|---|
| `tools\gen_shop_tables.js` | +`flatPair()`/BZ_ADVENTURE（109 行，四列归一化成对列表）+BZ_ACHIEVE_COND（2113 行 {t,t1,rq,tm}） |
| `hotfix-patch\core\bz-shops.generated.js` | 再生（263,547 B） |
| `hotfix-patch\core\bz-rpc-server.js` | ① CURRENCY_SLOTS + `4002:{f:'exp',k:'exp'}`（exp 缺省 0）② LoadGame 投 `baseValueAy[18]=s.exp` ③ `bumpTaskCounter()` 挂五个发奖口（getFinishTaskAward / circleTaskAward / getCircleTaskAward / quickFinishTask / getRogueFinishTaskAward）④ `recomputeAchievements()`（四类可判条件 → pending + taskData）⑤ getAchieveData 重算 + persist ⑥ GetRandomEventAward 重写（BZ_ADVENTURE 选列 + s.advDone 防重 + 未知分支不发不记 + 负数条目跳过）⑦ REJECT_CODES + `GetRandomEventAward:{dupClaim:4}` |
| `tools\facts\reject-codes.json` | +GetRandomEventAward（ev=index.js:143816#4a774bac，tier 2 静默）+receiveAchieveReward 注记更新 |
| `hotfix-patch\test\v271-smoke.js` | **新增** 13 条（三件拍板全覆盖） |
| `hotfix-patch\test\achieve-data.js` | 载入 bz-shops（旧 harness 缺 BZ_ACHIEVE_COND 是假绿）；T3-T6 换新契约（T6=持有 2601 → 137 进 pending 白拿回归） |
| `hotfix-patch\test\c16-smoke.js` | 白拿闸门断言更新（预热建槽后改验 pending 不含 354） |
| `hotfix-patch\test\circle-task.js` | 4002 入账断言（s.exp + note.eco.exp） |
| `hotfix-patch\probe\*.js` | 新增 5 个只读探针（语言/成就 des/真机验证/诊断） |

## 二、算法 v2.7.1（工人1 执行，主审复核）

- 工作区：`_incoming\v2.7.1-20261026\work\bz-oracle`（v2.7 整树复制 + 只覆盖 extract_shape.py/README.md，SHA256 双 True）。
- stdout：`actions 484 / unsafe 440 / unsafeByCrash 313 / unsafeByRetry 200 / zeroIsWrong 517`（重叠 80→73，313+200−440=73）。
- `--trace User.getBigGrowupData`：**26756 判空=否**（v2.7 误判已修）、**46175 判空=是且进重发判定** —— 上游 §三 两点主张全部实证。产物：`v271-stdout.json` / `v271-trace-gbgd.{out,err}.txt` / `worker-report.md`。

## 三、流水线与门禁

| 项 | 结果 |
|---|---|
| build-handlers | OK ver=h5ae2ccb6，selfCheck 1264 全过 |
| check_shape_freeze | C1-C8/C10-C13 全过，**diff 0** |
| acceptance | **44/44 绿**（43 旧 + v271-smoke 新增），known-red 0，cap 0 |
| check_reject_codes | OK 动作 47 / 条目 51 / 拒绝点 77 |
| 热重载 | pid 2655→2655 不变，impl h9454ce1e→**h5ae2ccb6**，implErr=null |

## 四、真机验证（codec+impl.handle 全链路，探针 `probe\v271-verify-probe.js`）

- 拍板 1：circleTaskAward(9003) → `rewardObj={4001:125,4002:50,4003:50}`、`eco={coins,exp:200,ptt}`、存档 `exp=200`（从 100 累加）、LoadGame `baseValueAy[18]=200`。
- 拍板 2：GetRandomEventAward(10, 分支 1) 首领进账 advDone，重复领回 4；wallet/bag 全程未动（2/3/4 只显示）。注：首轮探针把分支 1 打在真档上（advDone 已记），后续重复领符合预期。
- 拍板 3：getAchieveData → **pending 26**、taskData['1_3']=200、['6_2,0']=4；pending 26 条逐条本地复核无虚报（见 C1 §3.3）。
- 过程坑（复用价值）：handle 的 URL 必须含 `bzgf.maple-game.com`（否则黑洞静默）；handle 返回 `{status,text,meta}`；payload 信封要解 `md['User.动作名']`；cmd/probe 通道 eval 异步，res 有一拍延迟。

## 五、回滚

| 对象 | 位置 |
|---|---|
| 本轮全部源文件改前原件 | `_backup\20261026-172536-pre-v271\`（core/、patch-live/、hotfix-tools/、test/） |
| 算法工作区 | `_incoming\v2.7.1-20261026\work\`（独立目录，未碰 v2.7 原件） |
| 存档 | 真档本轮被验证动过（exp 200 / circleTotal 4 / advDone）——用户既有裁定「存档状况不重要，要的是正确的数据」 |
