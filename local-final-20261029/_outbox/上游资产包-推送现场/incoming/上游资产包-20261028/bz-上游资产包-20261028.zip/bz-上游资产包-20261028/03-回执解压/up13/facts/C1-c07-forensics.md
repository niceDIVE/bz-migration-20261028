# C1 · 第 8 批 C07〔善恶〕取证与策略（2026-10-27）

> 侦察：scoutF-c07-reqkeys.md（11 动作逐字段）。前一次 scoutE 用错 KEY 清单（主审凭记忆编造，10/11 无定义）——已返工，教训记 EXECUTION 轮 14。

## 成员与线上名（HttpConst index.js:60434-60451）

getGoodAndEvilTaskData / refreshGoodAndEvilTaskData / getGoodAndEvilNoteData / getGoodAndEvilNpcData /
refreshGoodAndEvilNpcData / getGoodAndEvilRankData / helpDoneTask / getGeHelpInfo / getGoodAndEvilData /
getGoodAndEvilRetireList / getGoodAndEvilRetireData。
使用点全部在 scripts3.js 同一 init（36347-36365）+ 请求点 36381-36702；全部 sendRequest。

## 策略：11 动作全锁（eRet 2 静默）

1. **玩法门槛**：善恶须先 JOIN_GOOD_OR_EVIL（index.js:60433，不在本批且未实现）——未入阵营原服本就拒绝。
2. **不能给半截成功**：GET_GOOD_AND_EVIL_DATA 成功时 GoodEvilInfoUI 对 goodAndEvilData 的 16 个字段
   全部 `.toString()` 直读（scripts3.js:35795-35861：prestige/historyMaxScore/curScore/todayScore/
   rankNum/total/av/curContribution/taskNum/maxTaskNum/totalTaskNum/totalReceiveNum/successRate/
   joinTime/joinDays）——缺键即 TypeError。
3. **helpDoneTask 会发 prestige/contribution/addScore**（36462-36468）——善恶贡献无存档槽，白给=伪造进度。
4. 回调分支核实：10 个动作非 1 无 else（静默）；helpDoneTask 非 1 非 6 静默（36471）。
5. note.attrch/skch 在 11 键回调内零出现（scoutF 逐节核对）——练功计时规则（accept3）不涉及本批。

登记：REJECT_CODES +11、reject-codes.json +11（ev = index.js 定义行 + sha8）。
形状：善恶 11 动作**不在 337 基线**（原服未对本档响应过/未捕获）→ 冻结 diff 0，无需审批。
