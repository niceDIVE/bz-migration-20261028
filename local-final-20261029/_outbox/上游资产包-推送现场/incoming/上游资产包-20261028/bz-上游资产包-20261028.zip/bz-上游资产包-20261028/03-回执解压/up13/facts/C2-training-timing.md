# C5 · C06 补充：练功按服务端计时结算（v2.7.1-accept3，2026-10-26）

> 上游 batch7-accept：C06 验收通过 + 补一条（限时 2 小时，做不出保持现状不来问）。

## 取证结论

1. **EndTraining 回调（index.js:120574-120601 逐行）完全不读 note**（只有 genguTime/hanyusuiTime/
   FishingModel/isSchoolAward/isCollective/skillArr/skillid）→ 按拍板规则"客户端确实读才结算"：
   EndTraining **不结算**，只做 Begin 记账/清账。
2. **EndMeditation 读 note.attrch.mpTrained**（138892）→ 写回 RoleBaseInfo.mpTrained；
   修为的持久槽 = **baseValueAy[32]**（客户端 70449/111789/74953 三处同源）。
3. 收益上限 = `getMaxNGBonus()`（index.js:121690-121701）= 最高内功技能等级 × 常量 33；
   常量 33 = MadNumber `_value[0]-offset` = 11252-11242 = **10**（_actIntv 交叉核对一致）。
   客户端自己会把 MP 加成 cap 在这个值上（142325 `Math.min(...)`），服务端修为只累加不封顶（加成侧封）。
4. 客户端没有"每分钟收益"的显示公式（结算在原服务端）→ 按拍板默认值 **1 点修为/分钟**。

## 实现

- BeginTraining 成功 → `s.trainBegin = {t: now, g: p.gTime}`（gTime=客户端总游戏时长秒，单次时长上限，<=0 视为无上限）+ persist。
- BeginMeditation 成功 → `s.medBegin = {t: now, g: p.gTime}` + persist。
- EndTraining → 清 trainBegin（不结算）。
- EndMeditation → 有记录才结算：`分钟 = floor(min(now-t, g*1000)/60000)`，`baseValueAy[32] += 分钟`，
  `note.attrch.mpTrained = 新值`，记录即清（一次 Begin 只结一次）；无记录 → 不结算不动档。
- 修一个真 bug：env.log 无条件读 `s.baseValueAy[32]`，空档上 baseValueAy 为 undefined →
  TypeError → catchNoCode 应答**丢 eRet**（形状冻结 diff 暴露的，真档有 baseValueAy 所以真机没炸）。

## 验证

- c06-smoke 10/10（新增 4 条：0 分钟不结算但记录清 / 90 分钟 +90 进 [32] / gTime=30s 封顶 0 / 无记录不动档）。
- 真机：Begin → 真实流逝 <1 分钟 → End 不结算 + 记录清 + 二次 End 不重复；定量由冒烟时钟注入覆盖。
- 门禁：build ver=h73b8869e、freeze diff 0、acceptance 46/46、reject-codes 65/79/102。
